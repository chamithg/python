from flask import Flask
#
from flask_app.models.ninja import Ninja
from flask_app.models.dojo import Dojo

app = Flask(__name__)