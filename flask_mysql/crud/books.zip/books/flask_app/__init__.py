from flask import Flask
#
from flask_app.models.author import Author
from flask_app.models.book import Book

app = Flask(__name__)