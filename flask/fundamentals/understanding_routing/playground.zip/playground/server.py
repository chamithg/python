from flask import Flask, render_template

app = Flask(__name__)    

@app.route('/')          
def hello_world():
    return 'Hello Playground!' 
 

@app.route('/play')          
def play():
    return render_template("play.html", num = 3 )  

@app.route('/play/<int:num>')          
def play1(num):
    return render_template("play.html", num = num, color = "cyan" )  

@app.route('/play/<int:num>/<color>')          
def play2(num,color):
    return render_template("play.html", num = num, color=color )  


if __name__=="__main__":   
    app.run(debug=True)    

